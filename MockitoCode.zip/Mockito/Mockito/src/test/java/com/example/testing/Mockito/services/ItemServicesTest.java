package com.example.testing.Mockito.services;

import com.example.testing.Mockito.Repo.ItemRepository;
import com.example.testing.Mockito.entity.Item;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ItemServicesTest {
    // private ItemServices itemServices;

    @InjectMocks
    private ItemServices itemServices;


    @Mock
    private ItemRepository itemRepository;

    @Test
    public void testStaticObject() {
        Item expect = new Item(5, "kola434242342", 4, 55);
        //   ItemServices itemServices = new ItemServices();
        Item actual = itemServices.retriveItems();
        assertEquals(actual, expect);
    }


    @Test
    public void testDataFromDB() {

        when(itemRepository.findAll()).thenReturn(
                Arrays.asList(
                        new Item(3, "item3", 4, 5),
                        new Item(2, "item2", 1, 5)
                )
        );

        List<Item> actual = itemServices.retriveItemsfromDB();
        for (Item item : actual) {

            System.out.println(item.toString());
        }

        assertEquals(actual.get(0).getValue(), 220);

    }
}
