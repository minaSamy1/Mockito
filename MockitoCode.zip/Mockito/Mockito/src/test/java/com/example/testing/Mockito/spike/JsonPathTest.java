package com.example.testing.Mockito.spike;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import org.h2.util.json.JSONItemType;
import org.junit.jupiter.api.Test;

import javax.crypto.spec.PSource;

public class JsonPathTest {


    @Test
    public void learning()
    {

        String responseFromService = "[" +
                "{\"id\":10000, \"name\":\"Pencil\", \"quantity\":5}," +
                "{\"id\":10001, \"name\":\"Pen\", \"quantity\":15}," +
                "{\"id\":10002, \"name\":\"Eraser\", \"quantity\":10}" +
                "]";

        DocumentContext documentContext= JsonPath.parse(responseFromService);
         int numberOfObject = documentContext.read("$.length()");
        System.out.println(" returned jspn contain >>  "+numberOfObject +" Object");

        System.out.println(" read first object "+documentContext.read("$.[0]"));
        System.out.println(" read from zero to third object >> "+documentContext.read("$.[0:3]"));
        System.out.println(" read the object from  the json which have name :ESAR : >>  "+ documentContext.read("$.[?(@.name=='Eraser')]").toString());
        System.out.println(" read the object from  the json which have quantity :5 : >>  "+documentContext.read("$.[?(@.quantity==5)]").toString());

    }
}
