package com.example.testing.Mockito;

import com.example.testing.Mockito.business.BussinessImpl;
import com.example.testing.Mockito.business.SomeDataServivces;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


/// the complex here we need to define subClass for each testcase  so if we use the database it
// will be hard
class SomeDataServiceSub implements SomeDataServivces {


    @Override
    public int[] getnumbers() {
        return new int[]{0, 1, 3};
    }
}

class SomeDataServiceemptySub implements SomeDataServivces {


    @Override
    public int[] getnumbers() {
        return new int[]{0, 1, 3};
    }
}

class SomeDataServiceFalseSub implements SomeDataServivces {


    @Override
    public int[] getnumbers() {
        return new int[]{0, 1, 3};
    }
}

public class BussinessSubTests {

    @Test
    public void runSuccessTest() {
        BussinessImpl bussiness = new BussinessImpl();
        bussiness.setSomeDataServices(new SomeDataServiceSub()); /// we send defined object from SomeDataServices
        int currentresult = bussiness.calculatewithServices();
        int expectedResu = 4;
        assertEquals(currentresult, expectedResu);


    }

    @Test
    public void runFailedest() {
        BussinessImpl bussiness = new BussinessImpl();
        bussiness.setSomeDataServices(new SomeDataServiceFalseSub());
        int currentresult = bussiness.calculatewithServices();
        int expectedResu = 4;
        assertEquals(currentresult, expectedResu);


    }

    @Test
    public void runEmptyTest() {
        BussinessImpl bussiness = new BussinessImpl();
        bussiness.setSomeDataServices(new SomeDataServiceemptySub());
        int currentresult = bussiness.calculatewithServices();
        int expectedResu = 0;
        assertEquals(currentresult, expectedResu);


    }
}
