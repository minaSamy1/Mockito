package com.example.testing.Mockito;

import com.example.testing.Mockito.business.BussinessImpl;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.assertEquals;

public class BussinessTests {

    @Test
    public void runSuccessTest()
    {
        BussinessImpl bussiness = new BussinessImpl();
        int currentresult= bussiness.calculate(new int[]{0,1,3});
        int expectedResu=4;
        assertEquals(currentresult,expectedResu);


    }

    @Test
    public void runFailedest()
    {
        BussinessImpl bussiness = new BussinessImpl();
        int currentresult= bussiness.calculate(new int[]{0,1,3});
        int expectedResu=4;
        assertEquals(currentresult,expectedResu);


    }

    @Test
    public void runEmptyTest()
    {
        BussinessImpl bussiness = new BussinessImpl();
        int currentresult= bussiness.calculate(new int[]{});
        int expectedResu=0;
        assertEquals(currentresult,expectedResu);


    }
}
