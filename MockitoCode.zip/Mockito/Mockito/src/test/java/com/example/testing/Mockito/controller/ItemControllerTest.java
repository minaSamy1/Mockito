package com.example.testing.Mockito.controller;

import com.example.testing.Mockito.entity.Item;
import com.example.testing.Mockito.services.ItemServices;
import org.hamcrest.core.StringContains;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Arrays;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

//@WebMvcTest(HelloWorldController.class)
@WebMvcTest(ItemController.class)
public class ItemControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private ItemServices itemServices;

    @Test
    public void test_basic() throws Exception {
        RequestBuilder req = MockMvcRequestBuilders.get("/items").accept(MediaType.APPLICATION_JSON_VALUE);
//        MvcResult result = mockMvc.perform(req).andReturn(); /// call the api
//        assertEquals("Hello-World", result.getResponse().getContentAsString());


        MvcResult result = mockMvc.perform(req).andExpect(status().isOk()).andExpect(content().json("{\"id\":5}")).andReturn();


    }


    @Test
    public void test_RealData_FromRepo() throws Exception {
//[
//        {
//            "id": 1,
//                "name": "product1",
//                "quantity": 4,
//                "price": 100,
//                "value": 400
//        },
//        {
//            "id": 2,
//                "name": "product2",
//                "quantity": 43,
//                "price": 32,
//                "value": 1376
//         }
//        ]

        // we consider as the ItemService run well and returned with the blow json
        when(itemServices.retriveItemsfromDB()).thenReturn(

                Arrays.asList(new Item(2, "kola", 4, 8), new Item(3, "Pepsico", 4, 3))

        );
        RequestBuilder req = MockMvcRequestBuilders.get("/itemsRealDB").accept(MediaType.APPLICATION_JSON_VALUE);
//        MvcResult result = mockMvc.perform(req).andReturn(); /// call the api
//        assertEquals("Hello-World", result.getResponse().getContentAsString());


        MvcResult result = mockMvc.perform(req).andExpect(status().isOk()).andExpect(content().json("[{\"id\":2,\"name\":\"kola\",\"quantity\":4,\"price\":8},{}]")).andReturn();  /// kindly note here we define the response as array of objects


    }

    @Test
    public void test_Post() throws Exception {
        RequestBuilder req = MockMvcRequestBuilders.post("/item").content("{\"id\":2,\"name\":\"kola\",\"quantity\":4,\"price\":8}").contentType(MediaType.APPLICATION_JSON_VALUE);
//        MvcResult result = mockMvc.perform(req).andReturn(); /// call the api
//        assertEquals("Hello-World", result.getResponse().getContentAsString());


        MvcResult result = mockMvc.perform(req).
                andExpect(status().isOk())

                .andReturn();


    }
}
