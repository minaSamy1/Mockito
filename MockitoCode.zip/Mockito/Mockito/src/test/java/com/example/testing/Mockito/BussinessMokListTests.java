package com.example.testing.Mockito;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.mockito.Mockito.times;

import java.util.ArrayList;
import java.util.List;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

public class BussinessMokListTests {

    @Test
    public void basic_list() {
        List mock = mock(List.class);
        when(mock.size()).thenReturn(5);
        System.out.println(" >>> " + mock.size());
        assertEquals(mock.size(), 4);

    }

    @Test
    public void returnDifferentValue() {
        List mock = mock(List.class);
        when(mock.size()).thenReturn(5).thenReturn(6);
        // System.out.println(" >>> "+mock.size());
        assertEquals(5, mock.size());
        assertEquals(6, mock.size());

    }

    @Test
    public void returnWithParamters() {
        List mock = mock(List.class);
        when(mock.get(0)).thenReturn("mina");
        // System.out.println(" >>> "+mock.size());
        assertEquals("mina", mock.get(0));
        //sassertEquals(6,mock.size());

    }

    @Test
    public void returnGenericParamters() {
        List mock = mock(List.class);
        when(mock.get(anyInt())).thenReturn("mina");  /// kda ay 7aga m4 get() hatrg3 mina
        // System.out.println(" >>> "+mock.size());
        assertEquals("mina", mock.get(90));
        //sassertEquals(6,mock.size());

    }

    @Test
    public void verification_basic() {
        List<String> mock = mock(List.class);
        String value1 = mock.get(0); // invoke here
        //String value1 = mock.get(0);
        verify(mock).get(0);  // check invoked or not
        verify(mock, times(1)).get(anyInt()); // if the get(0) invoked 1 times  it's test case
        verify(mock, atLeast(8)).get(anyInt()); // Faild
        //  verify(mock, atLeastOnce()).get(anyInt());

    }


    @Test
    public void argumentCapture() {

        List<String> mock = mock(List.class);
        mock.add("mina1");
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class); // to get the argument
        verify(mock).add(captor.capture());  // catch the paramter from the list
        assertEquals("mina17", captor.getValue());

    }

    @Test
    public void multipleArgumentCapture() {

        List<String> mock = mock(List.class);
        mock.add("mina1");
        mock.add("mina2");
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class); // to get the argument
        verify(mock,times(2)).add(captor.capture());// catch the paramter from the list

        List<String> paramters = captor.getAllValues();/// get all paramter which already sent
        assertEquals("mina1", paramters.get(0));
        assertEquals("mina2", paramters.get(1));

    }

    @Test
    public void mocks()
    {
         /// mock not
        ArrayList arraylistMock = mock(ArrayList.class);
        System.out.println(arraylistMock.get(0));
        System.out.println("size 1 :"+ arraylistMock.size());
        arraylistMock.add("test1");
        arraylistMock.add("test2");

        System.out.println(arraylistMock.get(0));
        System.out.println("size 2 :"+  arraylistMock.size());

        when(arraylistMock.size()).thenReturn(4);
        System.out.println("size 3 :"+ arraylistMock.size());

    }
    @Test
    public void spying()
    {
        /// mock not
        ArrayList arraylistSpy = spy(ArrayList.class);
       // System.out.println(arraylistSpy.get(0)); // as the object be come real so it's lead to IndexOutOfBoundsException

        arraylistSpy.add("test1");
        System.out.println( "read get(0)" +arraylistSpy.get(0));
        System.out.println("size 1 :"+ arraylistSpy.size());

        arraylistSpy.add("test2");

        System.out.println(arraylistSpy.get(0));
        System.out.println("size 2 :"+  arraylistSpy.size());

        when(arraylistSpy.size()).thenReturn(4);
        System.out.println("size 3 :"+ arraylistSpy.size());

    }


}
