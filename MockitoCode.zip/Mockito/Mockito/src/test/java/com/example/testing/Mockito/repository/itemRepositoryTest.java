package com.example.testing.Mockito.repository;


import com.example.testing.Mockito.Repo.ItemRepository;
import com.example.testing.Mockito.entity.Item;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DataJpaTest
public class itemRepositoryTest {
    @Autowired
    private ItemRepository itemRepository;

    @Test
    public void testFindAll() {
        List<Item> items = itemRepository.findAll();
        System.out.println(" count of row returned from DB " + items.size());
        assertEquals(items.size(), 3);

    }


    @Test
    public void testFindById() {
        Optional<Item> item = itemRepository.findById(2);
        System.out.println(" read Name : " + item.get().getName());
        assertEquals(item.get().getName(), "product27");
    }
}
