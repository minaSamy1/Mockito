package com.example.testing.Mockito;

import com.example.testing.Mockito.business.BussinessImpl;
import com.example.testing.Mockito.business.SomeDataServivces;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


/// the complex here we need to define subClass for each testcase  so if we use the database it
// will be hard
//@RunWith(MockitoJUnitRunner.class)
//@RunWith(MockitoJUnitRunner.class)

@ExtendWith(MockitoExtension.class)
public class BussinessMokTests {

    @InjectMocks
    BussinessImpl bussiness ;

    @Mock
    SomeDataServivces dataServiceMok  ;//= mock(SomeDataServivces.class);

//    @Before
//    public void before() {
//        bussiness.setSomeDataServices(dataServiceMok);
//
//    }


    @Test
    public void runSuccessTest() {

        // define the interface
        // SomeDataServivces dataServiceMok=mock(SomeDataServivces.class);
        when(dataServiceMok.getnumbers()).thenReturn(new int[]{0, 1, 3});


  //     bussiness.setSomeDataServices(dataServiceMok);

       // int currentresult = bussiness.calculatewithServices();
      //  int expectedResu = 4;
        assertEquals(bussiness.calculatewithServices(), 4);


    }

    @Test
    public void runFailedest()
    {
       // BussinessImpl bussiness = new BussinessImpl();
        when(dataServiceMok.getnumbers()).thenReturn(new int [] {9,2});


        bussiness.setSomeDataServices(dataServiceMok);
       // int currentresult= bussiness.calculatewithServices();

        assertEquals(bussiness.calculatewithServices(),11);


    }
//
//    @Test
//    public void runEmptyTest()
//    {
//        BussinessImpl bussiness = new BussinessImpl();
//        bussiness.setSomeDataServices(new SomeDataServiceemptySub());
//        int currentresult= bussiness.calculatewithServices();
//        int expectedResu=0;
//        assertEquals(currentresult,expectedResu);
//
//
//    }
}
