package com.example.testing.Mockito.controller;

import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {
@GetMapping(value="/hello")
    public String test()
    {


       System.out.println(" im in the Reall controller");
        return "Hello-World";
    }
}
