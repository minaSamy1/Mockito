package com.example.testing.Mockito.Repo;

import com.example.testing.Mockito.entity.Item;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemRepository extends JpaRepository<Item,Integer> {

}
