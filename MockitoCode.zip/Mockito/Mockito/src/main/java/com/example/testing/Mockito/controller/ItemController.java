package com.example.testing.Mockito.controller;

import com.example.testing.Mockito.entity.Item;
import com.example.testing.Mockito.services.ItemServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ItemController {

    @Autowired
    private ItemServices itemServices;
@GetMapping(value="/items")
    public Item dummyItems()
    {

   return new Item(5,"cars",3,1000);
    }


    @GetMapping(value="/itemsReal")
    public Item realItems()
    {
        return  itemServices.retriveItems();
    }


    @GetMapping(value="/itemsRealDB")
    public List<Item> realItemsDB()
    {

      return   itemServices.retriveItemsfromDB();
    }

    @PostMapping (value="/item")
    public void insertItm( Item item)
    {
        System.out.println( " read obect "+ item.toString());
    }
}
