package com.example.testing.Mockito.business;

public class BussinessImpl {

private SomeDataServivces someDataServices;
    public  int calculate(int [] data)
    {
        int sum=0;

        for( int value :data)
        {
            ///System.out.println(" read value from array " + value);
            sum+=value;


        }

        return sum;
    }

    public  int calculatewithServices()
    {
        int sum=0;
        int [] data= someDataServices.getnumbers();  // the service return data from DB
        for( int value :data)
        {
            ///System.out.println(" read value from array " + value);
            sum+=value;


        }

        return sum;
    }


    public SomeDataServivces getSomeDataServices() {
        return someDataServices;
    }

    public void setSomeDataServices(SomeDataServivces someDataServices) {
        this.someDataServices = someDataServices;
    }
}
