package com.example.testing.Mockito.business;

public interface SomeDataServivces {

    int [] getnumbers();
}
