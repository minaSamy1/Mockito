package com.example.testing.Mockito.services;

import com.example.testing.Mockito.Repo.ItemRepository;
import com.example.testing.Mockito.entity.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ItemServices {
    @Autowired
    private ItemRepository repo;

    public Item retriveItems() {

        return new Item(5, "kola434242342", 4, 55);


    }

    public List<Item> retriveItemsfromDB() {
        List<Item> items = repo.findAll();
        System.out.println("size of item list " + items.size());
        for (Item item : items) {

            item.setValue(item.getPrice() * item.getQuantity());
        }
        return items;

    }


}
