--
SELECT CURRENT_TIMESTAMP

insert into item ( id , name , price, quantity)  values ( 1, 'product1' ,100,4)
insert into item ( id , name , price, quantity)  values ( 2, 'product2' ,32,43)
insert into item ( id , name , price, quantity)  values ( 3, 'product3' ,5,5)